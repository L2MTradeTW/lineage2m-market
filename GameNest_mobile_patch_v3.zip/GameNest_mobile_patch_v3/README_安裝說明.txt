GameNest 手機版首頁補丁 V3
============================

本補丁只替換以下兩個檔案：
1. index.html
2. assets/css/style.css

安裝方式：
1. 解壓縮補丁包。
2. 將 index.html 上傳到 GitHub 專案最外層，選擇覆蓋原檔。
3. 開啟 assets/css 資料夾，將 style.css 上傳並覆蓋原檔。
4. 等待 GitHub Pages 約 1～3 分鐘更新。
5. 用網址後方加入 ?v=3 重新開啟，例如：
   https://l2mtradetw.github.io/lineage2m-market/?v=3

本次更新內容：
- 品牌改為 GameNest
- 標語：玩家的遊戲資產之家
- 手機優先的精簡首頁
- 鑽石圖示改為藍色 💎
- 稀有物品改為「伊甸沙哈八卦區」，連結 community.html
- 技能交易改為「物品交易區」，連結 item.html
- 任務委託改為「追殺令・物品收購」
- 新增手機底部導覽列
- 保留既有各功能頁，不刪除任何資料

注意：
- 本補丁沿用專案原有 assets/images/quest.webp 作為首頁背景。
- skill.html 仍保留在專案中，但首頁不再顯示技能交易入口。
